package grpc.smartbuilding;

import java.io.IOException;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class SmartBuildingServer {

	private Server server;

	private void start() throws IOException {
		int port = 50051;
		server = ServerBuilder.forPort(port).addService(new SmartBuildingServiceImpl()).build().start();
		System.out.println("Server started, listening on " + port);
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			System.err.println("*** shutting down gRPC server since JVM is shutting down");
			SmartBuildingServer.this.stop();
			System.err.println("*** server shut down");
		}));
	}

	private void stop() {
		if (server != null) {
			server.shutdown();
		}
	}

	/**
	 * Await termination on the main thread since the grpc library uses daemon
	 * threads.
	 */
	private void blockUntilShutdown() throws InterruptedException {
		if (server != null) {
			server.awaitTermination();
		}
	}

	public static void main(String[] args) throws IOException, InterruptedException {
		final SmartBuildingServer server = new SmartBuildingServer();
		server.start();
		server.blockUntilShutdown();
	}

	static class SmartBuildingServiceImpl extends SmartBuildingServiceGrpc.SmartBuildingServiceImplBase {

		@Override
		public void login(LoginRequest request, StreamObserver<APIResponse> responseObserver) {
			String username = request.getUsername();
			String password = request.getPassword();

			// Your login implementation logic here

			APIResponse response = APIResponse.newBuilder().setMessage("Login success").setSuccess(true).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}

		@Override
		public void logout(Empty request, StreamObserver<APIResponse> responseObserver) {
			// Your logout implementation logic here

			APIResponse response = APIResponse.newBuilder().setMessage("Logout success").setSuccess(true).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}

		@Override
		public void turnLightsOn(Empty request, StreamObserver<Result> responseObserver) {
			// Your turnLightsOn implementation logic here

			Result response = Result.newBuilder().setSuccess(true).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}

		@Override
		public void alarmOn(Empty request, StreamObserver<Result> responseObserver) {
			// Your alarmOn implementation logic here

			Result response = Result.newBuilder().setSuccess(true).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}

		@Override
		public void enableSecurity(Empty request, StreamObserver<Result> responseObserver) {
			// Your enableSecurity implementation logic here

			Result response = Result.newBuilder().setSuccess(true).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}

		@Override
		public void playMusic(Empty request, StreamObserver<Result> responseObserver) {
			// Your playMusic implementation logic here

			Result response = Result.newBuilder().setSuccess(true).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
}