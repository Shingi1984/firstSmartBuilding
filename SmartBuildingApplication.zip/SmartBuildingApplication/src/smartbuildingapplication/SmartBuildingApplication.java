package smartbuildingapplication;

import javax.swing.JOptionPane;

public class SmartBuildingApplication {

    public static void main(String[] args) {
        // Declare variables to track the status of different devices
        boolean isAlarmOn = false;
        boolean isLightOn = false;
        boolean isMusicOn = false;
        boolean isSecurityEnabled = false;

        // Display a welcome message and prompt the user to log in
        JOptionPane.showMessageDialog(null, "Welcome to the Smart Building Application!");
        String username = "user";
        String password = "1234";
        String inputUsername = JOptionPane.showInputDialog("Enter username");
        String inputPassword = JOptionPane.showInputDialog("Enter password");

        // Check if the login credentials are correct
        if (username.equals(inputUsername) && password.equals(inputPassword)) {
            JOptionPane.showMessageDialog(null, "Login successful!");

            // Prompt the user to select an action to perform
            String[] options = {"Turn lights on", "Turn alarm on", "Enable security", "Play music", "Exit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an action:", "Smart Building Login",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                    options, options[0]);

            // Based on the user's selection, call the appropriate method
            while (choice != JOptionPane.CLOSED_OPTION && choice != 4) {
                switch (choice) {
                    case 0:
                        turnLightsOn();
                        isLightOn = true;
                        break;
                    case 1:
                        alarmOn();
                        isAlarmOn = true;
                        break;
                    case 2:
                        enableSecurity();
                        isSecurityEnabled = true;
                        break;
                    case 3:
                        playMusic();
                        isMusicOn = true;
                        break;
                    default:
                        break;
                }

                // Prompt the user to select another action
                choice = JOptionPane.showOptionDialog(null, "Choose an action:", "Smart Building Login",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                        options, options[0]);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Please try again.");
        }
    }

    private static void turnLightsOn() {
        // Code to turn lights on
        JOptionPane.showMessageDialog(null, "Lights turned on.");
    }

    private static void alarmOn() {
        // Code to turn alarm on
        JOptionPane.showMessageDialog(null, "Alarm turned on.");
    }

    private static void enableSecurity() {
        // Code to enable security
        JOptionPane.showMessageDialog(null, "Security enabled.");
    }

    private static void playMusic() {
        // Code to play music
        JOptionPane.showMessageDialog(null, "Music playing.");
    }
}
