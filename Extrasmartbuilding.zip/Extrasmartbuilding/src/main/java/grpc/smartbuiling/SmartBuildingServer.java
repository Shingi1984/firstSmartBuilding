package grpc.smartbuiling;

import java.io.IOException;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class SmartBuildingServer {
	public static void main(String[] args) throws IOException, InterruptedException {
	    Server server = ServerBuilder.forPort(8080)
	        .addService(new SmartBuildingServiceImpl())
	        .build();
	    server.start();
	    server.awaitTermination();
	  }

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	

public void turnLightsOn(Empty request, StreamObserver<Result> responseObserver) {
  // TODO: Implement turnLightsOn logic
System.out.println("Receiving Request from Client.......");
  Result result = Result.newBuilder()
      .setSuccess(true)
      .build();
  responseObserver.onNext(result);
  responseObserver.onCompleted();
}

public void alarmOn(Empty request, StreamObserver<Result> responseObserver) {
  // TODO: Implement alarmOn logic
	System.out.println("Receiving Request from Client.......");
  Result result = Result.newBuilder()
      .setSuccess(true)
      .build();
  responseObserver.onNext(result);
  responseObserver.onCompleted();
}

public void enableSecurity(Empty request, StreamObserver<Result> responseObserver) {
  // TODO: Implement enableSecurity logic
	System.out.println("Receiving Request from Client.......");
  Result result = Result.newBuilder()
      .setSuccess(true)
      .build();
  responseObserver.onNext(result);
  responseObserver.onCompleted();
}

public void playMusic(Empty request, StreamObserver<Result> responseObserver) {
  // TODO: Implement playMusic logic
	System.out.println("Receiving Request from Client.......");
  Result result = Result.newBuilder()
      .setSuccess(true)
      .build();
  responseObserver.onNext(result);
  responseObserver.onCompleted();
}

}





