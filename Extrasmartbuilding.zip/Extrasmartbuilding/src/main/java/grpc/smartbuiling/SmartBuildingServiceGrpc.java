package grpc.smartbuiling;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 *service definition
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: smartbulding.proto")
public final class SmartBuildingServiceGrpc {

  private SmartBuildingServiceGrpc() {}

  public static final String SERVICE_NAME = "grpc.smartbuilding.SmartBuildingService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getTurnLightsOnMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TurnLightsOn",
      requestType = grpc.smartbuiling.Empty.class,
      responseType = grpc.smartbuiling.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getTurnLightsOnMethod() {
    io.grpc.MethodDescriptor<grpc.smartbuiling.Empty, grpc.smartbuiling.Result> getTurnLightsOnMethod;
    if ((getTurnLightsOnMethod = SmartBuildingServiceGrpc.getTurnLightsOnMethod) == null) {
      synchronized (SmartBuildingServiceGrpc.class) {
        if ((getTurnLightsOnMethod = SmartBuildingServiceGrpc.getTurnLightsOnMethod) == null) {
          SmartBuildingServiceGrpc.getTurnLightsOnMethod = getTurnLightsOnMethod = 
              io.grpc.MethodDescriptor.<grpc.smartbuiling.Empty, grpc.smartbuiling.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "grpc.smartbuilding.SmartBuildingService", "TurnLightsOn"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Result.getDefaultInstance()))
                  .setSchemaDescriptor(new SmartBuildingServiceMethodDescriptorSupplier("TurnLightsOn"))
                  .build();
          }
        }
     }
     return getTurnLightsOnMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getAlarmOnMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AlarmOn",
      requestType = grpc.smartbuiling.Empty.class,
      responseType = grpc.smartbuiling.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getAlarmOnMethod() {
    io.grpc.MethodDescriptor<grpc.smartbuiling.Empty, grpc.smartbuiling.Result> getAlarmOnMethod;
    if ((getAlarmOnMethod = SmartBuildingServiceGrpc.getAlarmOnMethod) == null) {
      synchronized (SmartBuildingServiceGrpc.class) {
        if ((getAlarmOnMethod = SmartBuildingServiceGrpc.getAlarmOnMethod) == null) {
          SmartBuildingServiceGrpc.getAlarmOnMethod = getAlarmOnMethod = 
              io.grpc.MethodDescriptor.<grpc.smartbuiling.Empty, grpc.smartbuiling.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "grpc.smartbuilding.SmartBuildingService", "AlarmOn"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Result.getDefaultInstance()))
                  .setSchemaDescriptor(new SmartBuildingServiceMethodDescriptorSupplier("AlarmOn"))
                  .build();
          }
        }
     }
     return getAlarmOnMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getEnableSecurityMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "EnableSecurity",
      requestType = grpc.smartbuiling.Empty.class,
      responseType = grpc.smartbuiling.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getEnableSecurityMethod() {
    io.grpc.MethodDescriptor<grpc.smartbuiling.Empty, grpc.smartbuiling.Result> getEnableSecurityMethod;
    if ((getEnableSecurityMethod = SmartBuildingServiceGrpc.getEnableSecurityMethod) == null) {
      synchronized (SmartBuildingServiceGrpc.class) {
        if ((getEnableSecurityMethod = SmartBuildingServiceGrpc.getEnableSecurityMethod) == null) {
          SmartBuildingServiceGrpc.getEnableSecurityMethod = getEnableSecurityMethod = 
              io.grpc.MethodDescriptor.<grpc.smartbuiling.Empty, grpc.smartbuiling.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "grpc.smartbuilding.SmartBuildingService", "EnableSecurity"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Result.getDefaultInstance()))
                  .setSchemaDescriptor(new SmartBuildingServiceMethodDescriptorSupplier("EnableSecurity"))
                  .build();
          }
        }
     }
     return getEnableSecurityMethod;
  }

  private static volatile io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getPlayMusicMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PlayMusic",
      requestType = grpc.smartbuiling.Empty.class,
      responseType = grpc.smartbuiling.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<grpc.smartbuiling.Empty,
      grpc.smartbuiling.Result> getPlayMusicMethod() {
    io.grpc.MethodDescriptor<grpc.smartbuiling.Empty, grpc.smartbuiling.Result> getPlayMusicMethod;
    if ((getPlayMusicMethod = SmartBuildingServiceGrpc.getPlayMusicMethod) == null) {
      synchronized (SmartBuildingServiceGrpc.class) {
        if ((getPlayMusicMethod = SmartBuildingServiceGrpc.getPlayMusicMethod) == null) {
          SmartBuildingServiceGrpc.getPlayMusicMethod = getPlayMusicMethod = 
              io.grpc.MethodDescriptor.<grpc.smartbuiling.Empty, grpc.smartbuiling.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "grpc.smartbuilding.SmartBuildingService", "PlayMusic"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  grpc.smartbuiling.Result.getDefaultInstance()))
                  .setSchemaDescriptor(new SmartBuildingServiceMethodDescriptorSupplier("PlayMusic"))
                  .build();
          }
        }
     }
     return getPlayMusicMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static SmartBuildingServiceStub newStub(io.grpc.Channel channel) {
    return new SmartBuildingServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static SmartBuildingServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new SmartBuildingServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static SmartBuildingServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new SmartBuildingServiceFutureStub(channel);
  }

  /**
   * <pre>
   *service definition
   * </pre>
   */
  public static abstract class SmartBuildingServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void turnLightsOn(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnimplementedUnaryCall(getTurnLightsOnMethod(), responseObserver);
    }

    /**
     */
    public void alarmOn(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnimplementedUnaryCall(getAlarmOnMethod(), responseObserver);
    }

    /**
     */
    public void enableSecurity(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnimplementedUnaryCall(getEnableSecurityMethod(), responseObserver);
    }

    /**
     */
    public void playMusic(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnimplementedUnaryCall(getPlayMusicMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getTurnLightsOnMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.smartbuiling.Empty,
                grpc.smartbuiling.Result>(
                  this, METHODID_TURN_LIGHTS_ON)))
          .addMethod(
            getAlarmOnMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.smartbuiling.Empty,
                grpc.smartbuiling.Result>(
                  this, METHODID_ALARM_ON)))
          .addMethod(
            getEnableSecurityMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.smartbuiling.Empty,
                grpc.smartbuiling.Result>(
                  this, METHODID_ENABLE_SECURITY)))
          .addMethod(
            getPlayMusicMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                grpc.smartbuiling.Empty,
                grpc.smartbuiling.Result>(
                  this, METHODID_PLAY_MUSIC)))
          .build();
    }
  }

  /**
   * <pre>
   *service definition
   * </pre>
   */
  public static final class SmartBuildingServiceStub extends io.grpc.stub.AbstractStub<SmartBuildingServiceStub> {
    private SmartBuildingServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private SmartBuildingServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected SmartBuildingServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new SmartBuildingServiceStub(channel, callOptions);
    }

    /**
     */
    public void turnLightsOn(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getTurnLightsOnMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void alarmOn(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getAlarmOnMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void enableSecurity(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getEnableSecurityMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void playMusic(grpc.smartbuiling.Empty request,
        io.grpc.stub.StreamObserver<grpc.smartbuiling.Result> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getPlayMusicMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   *service definition
   * </pre>
   */
  public static final class SmartBuildingServiceBlockingStub extends io.grpc.stub.AbstractStub<SmartBuildingServiceBlockingStub> {
    private SmartBuildingServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private SmartBuildingServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected SmartBuildingServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new SmartBuildingServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public grpc.smartbuiling.Result turnLightsOn(grpc.smartbuiling.Empty request) {
      return blockingUnaryCall(
          getChannel(), getTurnLightsOnMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.smartbuiling.Result alarmOn(grpc.smartbuiling.Empty request) {
      return blockingUnaryCall(
          getChannel(), getAlarmOnMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.smartbuiling.Result enableSecurity(grpc.smartbuiling.Empty request) {
      return blockingUnaryCall(
          getChannel(), getEnableSecurityMethod(), getCallOptions(), request);
    }

    /**
     */
    public grpc.smartbuiling.Result playMusic(grpc.smartbuiling.Empty request) {
      return blockingUnaryCall(
          getChannel(), getPlayMusicMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   *service definition
   * </pre>
   */
  public static final class SmartBuildingServiceFutureStub extends io.grpc.stub.AbstractStub<SmartBuildingServiceFutureStub> {
    private SmartBuildingServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private SmartBuildingServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected SmartBuildingServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new SmartBuildingServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.smartbuiling.Result> turnLightsOn(
        grpc.smartbuiling.Empty request) {
      return futureUnaryCall(
          getChannel().newCall(getTurnLightsOnMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.smartbuiling.Result> alarmOn(
        grpc.smartbuiling.Empty request) {
      return futureUnaryCall(
          getChannel().newCall(getAlarmOnMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.smartbuiling.Result> enableSecurity(
        grpc.smartbuiling.Empty request) {
      return futureUnaryCall(
          getChannel().newCall(getEnableSecurityMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<grpc.smartbuiling.Result> playMusic(
        grpc.smartbuiling.Empty request) {
      return futureUnaryCall(
          getChannel().newCall(getPlayMusicMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_TURN_LIGHTS_ON = 0;
  private static final int METHODID_ALARM_ON = 1;
  private static final int METHODID_ENABLE_SECURITY = 2;
  private static final int METHODID_PLAY_MUSIC = 3;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final SmartBuildingServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(SmartBuildingServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TURN_LIGHTS_ON:
          serviceImpl.turnLightsOn((grpc.smartbuiling.Empty) request,
              (io.grpc.stub.StreamObserver<grpc.smartbuiling.Result>) responseObserver);
          break;
        case METHODID_ALARM_ON:
          serviceImpl.alarmOn((grpc.smartbuiling.Empty) request,
              (io.grpc.stub.StreamObserver<grpc.smartbuiling.Result>) responseObserver);
          break;
        case METHODID_ENABLE_SECURITY:
          serviceImpl.enableSecurity((grpc.smartbuiling.Empty) request,
              (io.grpc.stub.StreamObserver<grpc.smartbuiling.Result>) responseObserver);
          break;
        case METHODID_PLAY_MUSIC:
          serviceImpl.playMusic((grpc.smartbuiling.Empty) request,
              (io.grpc.stub.StreamObserver<grpc.smartbuiling.Result>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class SmartBuildingServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    SmartBuildingServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return grpc.smartbuiling.SmartBuildingServiceImpl.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("SmartBuildingService");
    }
  }

  private static final class SmartBuildingServiceFileDescriptorSupplier
      extends SmartBuildingServiceBaseDescriptorSupplier {
    SmartBuildingServiceFileDescriptorSupplier() {}
  }

  private static final class SmartBuildingServiceMethodDescriptorSupplier
      extends SmartBuildingServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    SmartBuildingServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (SmartBuildingServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new SmartBuildingServiceFileDescriptorSupplier())
              .addMethod(getTurnLightsOnMethod())
              .addMethod(getAlarmOnMethod())
              .addMethod(getEnableSecurityMethod())
              .addMethod(getPlayMusicMethod())
              .build();
        }
      }
    }
    return result;
  }
}
